<?php
$site = isset($_GET['site']) ? $_GET['site']: null;
$go= base64_decode($site);
$domain = "http://safe.ai-link.me";
$title = "Ai Link";
// Favicon Wajib 160x160 dan ber format .ico //
$favicon = "http://www.ai-nime.tech/favicon.ico";
$ads_footer = "<iframe data-aa='418197' src='//ad.a-ads.com/418197?size=468x60' scrolling='no' style='width:468px; height:60px; border:0px; padding:0;overflow:hidden' allowtransparency='true'></iframe>";
$ads_atas = "";
$ads_tengah = "";
// Tulisan Dibawah Footer //
$url1 = "http://ai-nime.tech/";
$text1 = "Ai Nime Tech";
$url2 = "http://ai-nime.cf/";
$text2 = "Ai Nime";
// Untuk Background Cukup Masukan URL Gambar Saja //
$bg = "http://img04.deviantart.net/1e41/i/2015/152/a/f/owari_no_seraph_fan_art_by_kenkaizar-d8vonpx.png";
$textbutton = "Go To Link Meow";
$header = "Ai Safelink Solution";
// Username Fanspage //
$fp = "AiBatchNime";
// Nama Fanspage //
$namefp = "Ai Nime";
?>