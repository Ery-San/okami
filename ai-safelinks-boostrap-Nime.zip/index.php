<?php
require('config.php');
?>
<!-- Ai Safelink Solution -->

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> 
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href='<?php echo $favicon; ?>' rel='icon' type='image/x-icon'/>
<link rel="stylesheet" href="bootstrap.css">
<link rel="stylesheet" href="style.css">
<script src="bootstrap.js"></script>
<script src="jquery-1.11.1.js"></script> 
    <title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" href="bg.css" />
	<style>
	body{
     background-image:url("<?php echo $bg; ?>");background-repeat:no-repeat;background-position:top center;background-attachment:fixed;background-size:cover;}
    
	.aimenu{text-align:center;margin:15px auto;}
    .aitombol{font-family:segoe ui;font-weight:400;font-size:17px!important;background:rgba(143,73,64);margin:0 5px;padding:2px 4% 5px;}hr{border-top:1px solid #bbb!important;}
     </style>
	</head>
	<body>
	<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script> 
<div class="alert alert-info">
    <center>
    <strong><?php echo $header; ?></strong>
    </center>
  </div>

<br><br>
<center><?php echo $ads_atas; ?></center>
		<div class="container">
<div class="row">
<div class="panel panel-success">
  <div class="panel-heading"><center><b>Download </b></center></div>
  <div class="panel-body">
    <center> <a class="btn btn-md btn-primary" href="<?php echo $domain; ?>/redirect/?site=<?php echo base64_encode($go); ?>" role="button" target="_blank"><?php echo $textbutton; ?></a></center>

<br>
<font color="white">
<center>[ <a href="http://wap4dollar.com/ad/nonadult/serve.php?id=urk0kodd1x" rel="nofollow">Direct Download</a> ]</center>
</font>
<hr>

</div>
</div>
</div>
<!-- Submit Abis -->
<center><?php echo $ads_tengah; ?></center>
<br>
<!-- Info -->
<div class="panel panel-primary">
  <div class="panel-heading"><center><b>Info</b></center></div>
  <div class="panel-body">
  

<div class='aimenu'>

<button type="button" class="btn btn-success"><a class='label aitombol' href='<?php echo $url1; ?>' target='_blank'><?php echo $text1; ?></a></button>
<hr>
<button type="button" class="btn btn-success"><a class='label aitombol' href='<?php echo $url2; ?>' target='_blank'><?php echo $text2; ?></a></button>
</div>
<center>Recode By <a href="http://ai-nime.tech/" rel="nofollow">Ai - Nime</a> | <a href="https://www.facebook.com/victimslegiuns" rel="nofollow">Kentha Ishida</a> </center> 
<center> <div class="fb-page" data-href="https://www.facebook.com/<?php echo $fp; ?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/<?php echo $fp; ?>" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/<?php echo $fp; ?>"><?php echo $namefp; ?></a></blockquote></div></center> 
  </div>
</div>
<!-- Info End -->
</div>

</body>
<center><?php echo $ads_footer; ?></center>
<font color="white">
<small><center><?php echo $title; ?> - Copyright &copy; 2017</center></small>
</font>
    </html>